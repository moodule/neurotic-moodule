//Le module voice est un module de reconnaissance vocal.
//La configuration du format lu est stocker dans le fichier settings.
//La fonction voice_init est executer au demarrage de WVR.
//La fonction voice_callback est appeller pour transmettre les donn�es recu du Microphone.
//La fonction voice_texte est � appeller lorsque des donn�es on �t� traduite avec comme argument le texte traduit.

int (*voice_init)(void) = NULL;
int (*voice_callback)(char*,int,void (*)(char*)) = NULL;
void voice_texte(char *texte);