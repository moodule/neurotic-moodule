#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <dirent.h>
#include <string>
#include <cstdlib>

#ifdef WIN32
#include <windows.h>
#define sleep Sleep
#else
#include <unistd.h>
#endif

#include "wvr_widget.h"

extern "C" {
	#include <dlfcn.h>
}

#include "microphone/microphone.h"
#include "voice/voice.h"
#include "plugin/plugin.h"
#include "speak/speak.h"

plugin_fn *liste;
int liste_size = 0;
void plugin_register(plugin_fn fonction)
{
	liste_size++;
	plugin_fn *new_liste = (int(**)(char*, char*))malloc(sizeof(plugin_fn) * liste_size);
	if (liste_size != 1) memcpy(new_liste,liste,sizeof(plugin_fn) * (liste_size - 1));
	new_liste[liste_size - 1] = fonction;
	free(liste);
	liste = new_liste;
	return;
}

void voice_texte(char *texte);
int microphone_callback(char *data, int size)
{
	printf("Callback %s\n",data);
	return voice_callback(data,size,voice_texte);
}


void voice_texte(char *texte)
{
	char *recu;
	int i = 0;
	while (i < liste_size)
	{
		if (liste[0](texte,recu)) {
			speak(recu);
			free(recu);
			return;
		}
		i++;
	}
	speak("What?");
	return;
}

int main(int argc, char **argv)
{
	QApplication app(argc, argv);
	struct dirent *lecture;
    DIR *rep = opendir("modules");
	while ((lecture = readdir(rep)))
	{
		std::string name = "modules/";
		name = name + lecture->d_name;
		int found = name.find(".txt");
		if (found>0) {
			
			FILE *fichier = fopen(name.c_str(),"r");
			char buffer[65025];
			fgets(buffer, 65025, fichier);
			std::string sbuffer=buffer;
			fclose(fichier);
			int id_fin = sbuffer.find("|");
			int na_fin = sbuffer.find("|",id_fin + 1);
			int by_fin = sbuffer.find("|",na_fin + 1);
			int fn_fin = sbuffer.size();
			std::string id = sbuffer.substr(0,id_fin);
			std::string na = sbuffer.substr(id_fin + 1,na_fin - (id_fin + 1));
			std::string by = sbuffer.substr(na_fin + 1,by_fin - (na_fin + 1));
			printf("Importation de %s by %s : \n", na.c_str(),by.c_str());
			std::string dlname = "modules/" + id + ".dll";
			void *hndl = dlopen(dlname.c_str(),RTLD_LAZY);
			char *pch = (char*)sbuffer.substr(by_fin + 1,fn_fin - (by_fin + 1)).c_str();
			char *new_pch;
			while (true)
			{
				
				new_pch=strchr(pch,',');
				if (new_pch!= NULL) new_pch[0] = '\0';
				printf(" - %s\n", pch);
				if (strcmp("microphone_init",pch) == 0) microphone_init = (int (*)(int (*)(char*, int)))dlsym(hndl, pch);
				if (strcmp("voice_callback",pch) == 0) voice_callback = (int (*)(char*, int,void (*)(char*))) dlsym(hndl, pch);
				if (strcmp("voice_init",pch) == 0) voice_init = (int(*)())dlsym(hndl, pch);
				if (strcmp("speak_init",pch) == 0) speak_init = (int(*)())dlsym(hndl, pch);
				if (strcmp("speak",pch) == 0) speak = (void(*)(char*)) dlsym(hndl, pch);
				if (strcmp("module",pch) == 0) {
					plugin_fn fonction;
					fonction = (int(*)(char*,char*))dlsym(hndl, pch);
					plugin_register(fonction);
				}
				if (strcmp("init",pch) == 0) {
					printf("Init");
					plugin_init fonction;
					fonction = (void(*)())dlsym(hndl, pch);
					fonction();
				}
				if (new_pch == NULL) break;
				pch = new_pch + 1;
				
			}
			
		}
	}
	closedir(rep);
	
	QString serreur = "Il manque des modules pour : ";

	int erreur = 0;
	if (microphone_init == NULL) {
		serreur = serreur + "\n - Le microphone";
		erreur = 1;
	}
	if (speak_init == NULL) {
		erreur = 1;
	}
	if (speak == NULL) {
		serreur = serreur + "\n - La voix de l'ordinateur";
		erreur = 1;
	}
	if (voice_init == NULL) {
		erreur = 1;
	}
	if (voice_callback == NULL) {
		serreur = serreur + "\n - La reconnaissance vocal";
		erreur = 1;
	}
	if (erreur) {
	QMessageBox::critical(NULL, "Modules manquant!", serreur);
	return 0;
	}
	
	
	wvr_widget widget;

	
	if (!voice_init()) QMessageBox::critical(NULL, "Erreur!", "Erreur lors de l'initialisation de la reconnaissance vocal!");
	else if (!speak_init()) QMessageBox::critical(NULL, "Erreur!", "Erreur lors de l'initialisation de la voix de l'ordinateur!");
	else if (!microphone_init(microphone_callback)) QMessageBox::critical(NULL, "Erreur!", "Erreur lors de l'initialisation du Microphone!");
	else return app.exec();
	return 0;
}