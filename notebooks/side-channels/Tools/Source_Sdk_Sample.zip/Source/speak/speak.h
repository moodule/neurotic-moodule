//Le module speak sert � faire parler l'ordinateur.
//La fonction speak_init est executer au demarrage de WVR.
//La fonction speak sera appeler pour demander � au module de dire quelque chose.

int (*speak_init)(void) = NULL;
void (*speak)(char*) = NULL;