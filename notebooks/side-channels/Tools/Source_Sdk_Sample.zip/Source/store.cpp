#include "store.h"

int main(int argc, char **argv)
{
    QApplication app(argc, argv);
 
    StoreWindow window;
    window.show();
 
    return app.exec();
}

StoreWindow::StoreWindow() : QWebView()
{
	//QWebView *view = new QWebView(this);
	load(QUrl("http://89.157.134.193:8080/WorldVoiceRecogniton/store/"));
	QObject::connect(this, SIGNAL(urlChanged(const QUrl &)), this, SLOT(ViewUrlChanged(const QUrl &)));
	resize(1024,760);
}

StoreWindow::~StoreWindow()
{
}

void StoreWindow::ViewUrlChanged(const QUrl & url)
{
	std::string surl = url.toString().toStdString();
	int found = surl.find("?id=");
	if (found < 1) return;
	std::string num = surl.substr(found + 4,surl.size() - (found + 4));
	downloadurl1 = "/WorldVoiceRecogniton/store/modules/" + num + ".dll";
	downloadurl2 = "/WorldVoiceRecogniton/store/modules/" + num + ".txt";
	requete = new QHttp("89.157.134.193",QHttp::ConnectionModeHttp,8080);
	std::string filename1 = "modules/" + num + ".dll";
	std::string filename2 = "modules/" + num + ".txt";
	FILE *fichier = fopen(filename2.c_str(),"r");
	if (fichier != NULL) {
		fclose(fichier);
		remove(filename1.c_str());
		remove(filename2.c_str());
		QMessageBox::information(this, "Information", "Le module � �t� desinstaller.");
		QString stringurl = "http://89.157.134.193:8080/WorldVoiceRecogniton/store/uninstall.php?num=";
		stringurl = stringurl + num.c_str();
		
		setUrl(stringurl);
	} else {
	fichier1 = new QFile(filename1.c_str());
	fichier2 = new QFile(filename2.c_str());
	fichier1->open(QIODevice::WriteOnly);
	fichier2->open(QIODevice::WriteOnly);
	
	QHttpRequestHeader httpHeader1("GET", downloadurl1.c_str());
    httpHeader1.setValue("Host", QUrl("89.157.134.193:8080").host());
	requete->request(httpHeader1);
	requete->get(downloadurl1.c_str(),fichier1);
		progress = new QProgressBar();
		progress->show();
	connect(requete, SIGNAL(done(bool)), this, SLOT(InstallPhase2(bool)));
	connect(requete, SIGNAL(dataReadProgress(int,int)), this, SLOT(ProgressBarChange(int,int)));
	}
	return;
}

void StoreWindow::InstallPhase2(bool erreur)
{
	delete requete;
	requete = new QHttp("89.157.134.193",QHttp::ConnectionModeHttp,8080);
	QHttpRequestHeader httpHeader2("GET", downloadurl2.c_str());
    httpHeader2.setValue("Host", QUrl("89.157.134.193:8080").host());
	requete->request(httpHeader2);
	requete->get(downloadurl2.c_str(),fichier2);
	connect(requete, SIGNAL(done(bool)), this, SLOT(InstallPhase3(bool)));
}

void StoreWindow::InstallPhase3(bool erreur)
{
	QMessageBox::information(this, "Information", "Le module � �t� installer.");
	triggerPageAction(QWebPage::Back);
	delete requete;
	delete fichier1;
	delete fichier2;
	delete progress;
}

void StoreWindow::ProgressBarChange(int prc, int tot) {
	progress->setMaximum(tot);
	progress->setValue(prc);
	return;
}