#include <iostream>
#include <string>
#include <QApplication>
#include <QWidget>
#include <QUrl>
#include <QFile>
#include <QHttp>
#include <QLabel>
#include <QWebView>
#include <QMessageBox>
 #include <QWebPage>
  #include <QProgressBar>

class StoreWindow : public QWebView
{
	Q_OBJECT
	public:
StoreWindow();
~StoreWindow();
	public slots:
void ViewUrlChanged(const QUrl & url);
void InstallPhase2(bool erreur);
void InstallPhase3(bool erreur);
void ProgressBarChange(int, int);
	private:
QHttp *requete;
std::string downloadurl1;
std::string downloadurl2;
QFile *fichier1;
QFile *fichier2;
QProgressBar *progress;
};