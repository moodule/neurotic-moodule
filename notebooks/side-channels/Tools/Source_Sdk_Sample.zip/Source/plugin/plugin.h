//Cr�e une fonction plugin_fn nomm�e init pour qu'elle soit appeller au demmarage de WVR.
typedef void (*plugin_init)(void);

//Cr�e une fonction plugin_fn nomm�e module.
//Cette fonction sera appeller lorsque du texte sera traduit. Cette texte traduit sera contenue dans le premier char*.
//Si le texte traduit ne correspond pas � la fonction, renvoyer 0, sinon renvoyer, 1 et le texte � repondre dans le 2�me char*.
typedef int (*plugin_fn)(char*, char*);