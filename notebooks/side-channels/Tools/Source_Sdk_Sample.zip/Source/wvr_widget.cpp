#include "wvr_widget.h"

wvr_widget::wvr_widget()
{
	QIcon icone("icone.ico");
	QSystemTrayIcon *tray = new QSystemTrayIcon(icone,this);
	
	QMenu *menu = new QMenu();
	QAction *quitter = menu->addAction("Quitter");
	connect(quitter, SIGNAL(triggered()), qApp, SLOT(quit()));
	tray->setContextMenu(menu);
	
	
	tray->show();
	tray->showMessage ("World Voice Recognition", "World Voice Recognition est maintenent demarrer!");
}

wvr_widget::~wvr_widget()
{
}