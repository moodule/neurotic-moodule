#include <QApplication>
#include <QMessageBox>
#include <QObject>
#include <QSystemTrayIcon>
#include <QMenu>
#include <QAction>

class wvr_widget : public QWidget
{
	public:
wvr_widget();
~wvr_widget();
};