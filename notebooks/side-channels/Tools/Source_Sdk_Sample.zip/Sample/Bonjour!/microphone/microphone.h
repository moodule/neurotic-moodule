//Le module Microphone lit, et transmet les donn�es recu du Microphone au module de reconnaissance vocal.
//La configuration du format � lire est stocker dans le fichier settings.
//La fonction microphone_init est appeller au demarrage de WVR.
//La fonction microphone_callback est a appeller pour transmettre des donn�es data de taille size.

int microphone_init(int (*microphone_callback_fn)(char*, int));