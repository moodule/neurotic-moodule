#include <iostream>
#include <string.h>
#include <cstdio>
#include <windows.h>

#include "microphone/microphone.h"

int microphone_init(int (*microphone_callback_fn)(char*, int))
{
	std::cout << "Microphone : Envoie des donn�es de test..." << std::endl;
	char *data = "Donn�es de Test";
	//microphone_callback_fn(data,strlen(data));
	return true;
}

#include "voice/voice.h"
int voice_init()
{
	std::cout << "Initialisation de Voice" << std::endl;
	return 1;
}

int voice_callback(char* data, int size,void (*voice_texte_fn)(char*))
{
	std::cout << "Voice : La fonction callback a recu : " << data << std::endl;
	voice_texte_fn(data);
	return 1;
}

#include "speak/speak.h"
int speak_init()
{
	std::cout << "Initialisation de speak" << std::endl;
	FILE *fichier = fopen("script.vbs","w");
	fputs("Set oSound = CreateObject(\"sapi.SPVoice\")\noSound.Rate = 1\noSound.speak WScript.Arguments(0)\n",fichier);
	fclose(fichier);
	char *name = getenv ("USERNAME");
	std::string bonjour = "\"Bonjour ";
	bonjour = bonjour	+ name;
	bonjour = bonjour   + "!\"";
	speak((char*)bonjour.c_str());
	return 1;
}

void speak(char *texte)
{
	std::string commande = "script.vbs ";
	commande = commande + texte;
	system(commande.c_str());
	std::cout << "Speak : " << texte << std::endl;
	return;
}