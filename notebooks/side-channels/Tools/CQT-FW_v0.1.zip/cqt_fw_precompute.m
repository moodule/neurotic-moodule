function cqt_fw_precompute(f_min, fs, precisao, la440, f_max, passo)

% Jonathan Alis Salgado Lima
% Universidade de Brasilia
% jonathanalis@gmail.com

% funcao que precomputa os parametros, os coeficientes do filtro e o ganho
% da CQT-FW. ela cria os arquivos cqt_fw_filter.mat, cqt_fw_params.mqt e
% cqt_fw_gain.mat. Arquivos que sao necessarios na funcao cqt_fw.
%
% entradas:
% f_min eh a frequencia minima, default 110 hz
% fs eh a nova frequencia de amostragem, usado para o resampling.
% precisao eh o numero de frequencias por oitava, default eh 96
% la440, eh a frequencia da nota La4, default eh 440
% f_max eh a frequencia maxima, default 1000, maximo eh fs/2.


print_gain=0;
print_filtro=0;

fprintf('Aplicando a CQT-FW\nOpcoes:\n');
fprintf('Imprimir filtros: %d \n',print_filtro);
fprintf('Imprimir resultados do ganho: %d \n',print_gain);
if nargin < 4,
    la440 = 440;
end

if nargin < 3,
    precisao = 96;
end

if nargin < 2,
    fs = 2205;
end

if nargin < 5,
    f_max = 1000;
end
if nargin < 6,
    passo=150;
end

if nargin < 1,
    f_min = 110;
end

%salvando os parametros.
save cqt_fw_params.mat f_min fs precisao la440 f_max passo

%num de oitavas
num_oit=log2(f_max/f_min);
%calculando as fks
k=0:floor(num_oit*precisao);
fk=power(2,(k)/precisao)*f_min;
fk0a1=fk*2/(fs);% de 0 a 1, sendo 1 igual a pi
fk0a1_prev=power(2,(-1)/precisao)*f_min*2/fs;
fk0a1_next=power(2,(floor(num_oit*precisao)+1)/precisao)*f_min*2/fs;

%gerando o sinal de teste para obter o ganho(um ruido branco de 10 segundos)
x_teste=zeros(1,441000);
x_teste=20*awgn(x_teste,0);

if print_gain
    plot(x_teste);
end
xx=x_teste;
gain=ones(1,length(k));

midi = 69 + 12*log(fk/la440)/log(2);
%calculando o Q
c1=0.3;
c2=2.0/3;
Q=1/(c1*(power(2,1/precisao)-power(2,-1/precisao)));

for i=1:length(k)
    
    if i~=1 && i~=length(k)
        Wp=[fk0a1(i)-c1*(fk0a1(i)-fk0a1(i-1)) fk0a1(i)+c1*(fk0a1(i+1)-fk0a1(i))];
        Ws=[fk0a1(i)-c2*(fk0a1(i)-fk0a1(i-1)) fk0a1(i)+c2*(fk0a1(i+1)-fk0a1(i))];
    end
    if i==1
        Wp=[fk0a1(i)-c1*(fk0a1(i)-fk0a1_prev) fk0a1(i)+c1*(fk0a1(i+1)-fk0a1(i))];
        Ws=[fk0a1(i)-c2*(fk0a1(i)-fk0a1_prev) fk0a1(i)+c2*(fk0a1(i+1)-fk0a1(i))];
    end
    
    if i==length(k)
        Wp=[fk0a1(i)-c1*(fk0a1(i)-fk0a1(i-1)) fk0a1(i)+c1*(fk0a1_next-fk0a1(i))];
        Ws=[fk0a1(i)-c2*(fk0a1(i)-fk0a1(i-1)) fk0a1(i)+c2*(fk0a1_next-fk0a1(i))];
    end
    Rp=0.1;
    Rs=20;
    [N,Wn] = cheb1ord(Wp, Ws, Rp, Rs);
    %frequencia_central=fk(i)
    %N
    [b(i,:),a(i,:)] = cheby1(N,Rp,Wn);
    if print_filtro
	        if i>1 && i<length(k)
	            b(i,:);
	            a(i,:);
	            [h,omega] = freqz(b(i,:),a(i,:),1024*64);
	            frequencia_central=fk(i)
	            subplot(2,1,1);
	            gain = 20*log10(abs(h));
	            plot (omega/pi,gain);grid;
	            xlabel('Frequ�ncia angular normalizada (\omega/\pi)'); ylabel('Resposta do filtro, dB');
	            title('Resposta do filtro Chebychev I Passa-banda em dB');
	            xlim([0 1]);
	            subplot(2,1,2);
	            gain = (abs(h));
	            plot (omega/pi,gain);grid;
	            xlabel('Frequ�ncia angular normalizada (\omega/\pi)'); ylabel('Resposta do filtro');
	            title('Resposta do filtro Chebychev I Passa-banda, de fk-1 a fk+1');
	            xlim([fk0a1(i-1) fk0a1(i+1)]);
	            text(fk0a1(i),0.2,'\downarrow fk');
	            text(fk0a1(i-1),0.2,'\downarrow fk-1');
	            text(fk0a1(i+1),0.2,'\downarrow fk+1');
	            text(Wp(1),1.2,'\downarrow inicio da BP');
	            text(Wp(2),1.2,'\downarrow fim da BP');
	            text(Ws(1),0.5,'\downarrow fim da BR');
	            text(Ws(2),0.5,'\downarrow inicio da BR');
	            pause();
	        end
	    end
end
 save cqt_fw_filter.mat a b
%downsampling.
sinalEntrada=resample(xx,fs,44100);


tamBlackman=passo*3;
tamJanela=passo*15;
%separando a entrada em janelas
n_janelas=ceil(length(sinalEntrada)/tamJanela);
%zero padding
x1=[zeros(1,tamJanela/2) sinalEntrada zeros(1,((n_janelas+1)*(tamJanela))-length(sinalEntrada))];
%tampadding=length(x1);

n_passos=floor(length(sinalEntrada)/passo);
t=passo*(0:n_passos-1);
X=zeros(length(k),n_passos);
X0=zeros(length(k),n_passos);
X1=zeros(length(k),n_passos);

tic
for i=1:n_passos
    
    %fprintf('\r%f porcento',100*i/n_passos);
    xk=x1(((i-1)*passo+1):((i)*passo+tamJanela));
    %deixar a jenala do tamanho do sinal
    zeros2add=length(xk)-length([zeros(1,floor(length(xk)/2)-floor(tamBlackman/2)) blackman(tamBlackman)' zeros(1,floor(length(xk)/2)-floor(tamBlackman/2) )]);
    xk=[zeros(1,floor(length(xk)/2)-floor(tamBlackman/2)) blackman(tamBlackman)' zeros(1,floor(length(xk)/2)-floor(tamBlackman/2)+zeros2add )].*xk;
    
    for j=1:length(k)
        y=filtfilt(b(j,:),a(j,:),xk);
        X0(j,i)=sqrt(sum(y.*y));
    end
end
toc
if print_gain
    figure();
    grid on;
    subplot(1,1,1);
    imagesc(t/fs,midi,-X0);
    grid on;
    colormap('gray');
    set(gca,'YDir','normal')
    xlabel('Tempo (Segundos)');
    ylabel('Nota midi');
end
for i=1:length(k)    
    gain(i)=sum(X0(i,:));
end
%passa baixa no ganho, para obter o comportamento medio.
%usamos filtro gaussiano com desvio padrao de meio "nota musical"
b=[-precisao/12:precisao/12];
sigma=precisao/24;
h=1/(sqrt(2*pi)*sigma)*exp(-0.5*b.^2/(sigma^2));
result=conv(gain,h);
idx = ceil ((length(result) - length(k)) / 2);
gain = result(idx+1:idx+length(k));

if print_gain
    figure();
    plot(gain);
end
save cqt_fw_gain.mat gain
for i=1:length(k)
    X0(i,:)=X0(i,:)*1.0/gain(i);
end

if print_gain
    figure();
    grid on;
    subplot(1,1,1);
    imagesc(t/fs,midi,-X0);
    grid on;
    colormap('gray');
    set(gca,'YDir','normal')
    xlabel('Tempo (Segundos)');
    ylabel('Nota midi');
    
    
end
end

