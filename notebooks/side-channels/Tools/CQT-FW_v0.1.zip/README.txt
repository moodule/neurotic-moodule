CQT-FW v0.1.
Jonathan Alis Salgado Lima
Universidade de Brasilia

Baseado no artigo:
Transformada Q Constante de Comprimento de Janela Fixo
2012-cea-jalis-v7.pdf

arquivos:
cqt_fw.m
cqt_fw_precompute.m
compute_f0gram.m

Requisitos:
MATLAB
ou OCTAVE, com as bibliotecas octave-signal e octave-communications

Como funciona:
Abra o MATLAB ou OCTAVE.
primeiro rode cqt_fw_precompute, com os parametros desejados.
Depois rode cqt_fw('audio.wav');
o resultado ser� uma imagem contendo as notas musicais(frequencias fundamentais) do audio passado.
a figura midi_notas.gif(http://www.phys.unsw.edu.au/jw/notes.html) 
mostra a correspondencia entre notas midi e notas musicais.

exemplo rapido:
cqt_fw_precompute();
cqt_fw('ukulele.wav');
o resultado eh o mesmo da figura 5)b do artigo.

outras opcoes:
1 - em cqt_fw.m temos a opcao de gerar o espectrograma da CQT-FW e/ou o f0grama gerado por ela. 
configuramos isso setando a variavel f0grama em cqt_fw.m

2 - em cqt_fw.m temos a opcao de aplicar ou nao o ganho, configuramos isso com a variavel aplicar_ganho.

3 - em cqt_fw_precompute.m, se usarmor a funcao sem nenhum parametros, teremos:
f_min=110, fs=2005, 96 frequencias de analise por oitava, la4 com frequencia 440, f_max=1000, e passo de 150 amostras.
podem ser configurados como passagem dos parametros da funcao cqt_fw_precompute.

4 - em cqt_fw_precompute.m temos ainda a opcao de ver os filtros, e ver a funcao do ganho
para configurar basta setar as variaveis print_gain e print_filtro.

5 - em compute_f0gram, podemos escolher se aplicamos a normalizacao ou nao, basta alterar o terceiro parametro
de compute_f0gram para 0, na linha 141 de cqt_fw.

--------------------//--------------------------------------

Adicionado na v0.1:
1 - agora, al�m de funcionar no MATLAB, funciona tamb�m nas versoes mais recentes do octave, 
mas precisamos da biblioteca de processamento de sinais.

2 - o filtro passa baixa do ganho foi alterado para um gaussiano, em que a largura dele depende agora da precisao
de tal forma que ele se adapta a ela.

--------------------//--------------------------------------
