function [X,fk,t]=cqt_fw(audio_name)

% Jonathan Alis Salgado Lima
% Universidade de Brasilia
% jonathanalis@gmail.com

% saidas:
% X eh o espectro
% f sao as frequencias de analise
% t, vetor com o tempo
%entradas:
% x eh o nome do arquivo .wav

% funcionamento:
% a partir do arquivo de audio fornecido, computa o espectrograma de acordo
% com a CQT-FW, com os parametros fornecidos pela funcao cqt_fw_precompute.
% Tem a opcao de gerar o f0-grama, um espectrograma que cont�m apenas as
% frequencias fundamentais, ou seja, as notas musicais. temos tambem a
% opcao de aplicar o ganho fornecido por cqt_fw_precompute.



%se f0grama for 0, mostra o grafico apenas do spectrograma da CQT-FW
%se for 1, mostra o grafico da do f0grama
%se for 2, mostra ambos.
f0grama=1;
aplicar_ganho=1;

fprintf('Aplicando a CQT-FW\nOpcoes:\n');
fprintf('Aplicar f0grama: %d \n',f0grama);
fprintf('Aplicar ganho: %d \n',aplicar_ganho);

if nargin < 1,
    error('cqt_fw precisa de pelo menos um argumento');
end



%colocando o sinal em um unico canal.
[x,fs_original]=wavread(audio_name);
tam=size(x);
%tam=wavread(audio_name,'size')
xx=zeros(1,tam(1));
for i=1:tam
    xx(i)=sum(x(i,:));
end
clear x;
%carregando os parametros gerados por cqt_fw_precompute. exit se nao
%encontrar o arquivo cqt_fw_params.mat
try
    load cqt_fw_params.mat
catch ME1
    fprintf('Arquivo cqt_fw_param.mat nao encontrado, Rode a funcao cqt_fw_precompute\n');
    exit;
end
%num de oitavas
num_oit=log2(f_max/f_min);
%calculando as fks
k=0:floor(num_oit*precisao);
fk=power(2,(k)/precisao)*f_min;
fk0a1=fk*2/(fs);% de 0 a 1, sendo 1 igual a pi
fk0a1_prev=power(2,(-1)/precisao)*f_min*2/fs;
fk0a1_next=power(2,(floor(num_oit*precisao)+1)/precisao)*f_min*2/fs;
midi = 69 + 12*log(fk/la440)/log(2);

%carregando os coeficientes do filtro.
%se nao encontrar o arquivo cqt_fw_filter.mat, calcula-os.
try
    load cqt_fw_filter.mat
catch ME2
    fprintf('Arquivo cqt_fw_filter.mat nao encontrado. Gerando os coeficientes dos filtros.\n');
    %calculando o Q
    c1=0.3;
    c2=2.0/3;
    Q=1/(c1*(power(2,1/precisao)-power(2,-1/precisao)));    
    for i=1:length(k)
        
        if i~=1 && i~=length(k)
            Wp=[fk0a1(i)-c1*(fk0a1(i)-fk0a1(i-1)) fk0a1(i)+c1*(fk0a1(i+1)-fk0a1(i))];
            Ws=[fk0a1(i)-c2*(fk0a1(i)-fk0a1(i-1)) fk0a1(i)+c2*(fk0a1(i+1)-fk0a1(i))];
        end
        if i==1
            Wp=[fk0a1(i)-c1*(fk0a1(i)-fk0a1_prev) fk0a1(i)+c1*(fk0a1(i+1)-fk0a1(i))];
            Ws=[fk0a1(i)-c2*(fk0a1(i)-fk0a1_prev) fk0a1(i)+c2*(fk0a1(i+1)-fk0a1(i))];
        end
        
        if i==length(k)
            Wp=[fk0a1(i)-c1*(fk0a1(i)-fk0a1(i-1)) fk0a1(i)+c1*(fk0a1_next-fk0a1(i))];
            Ws=[fk0a1(i)-c2*(fk0a1(i)-fk0a1(i-1)) fk0a1(i)+c2*(fk0a1_next-fk0a1(i))];
        end
        Rp=0.1;
        Rs=20;
        [N,Wn] = cheb1ord(Wp, Ws, Rp, Rs);
        [b(i,:),a(i,:)] = cheby1(N,Rp,Wn);
        % frequencia_central=fk(i)
        % N
    end
end

%downsampling:
sinalEntrada=resample(xx,fs,fs_original);
%sound(sinalEntrada, fs);

%calculando tamanho da janela.

tamBlackman=passo*3;
tamJanela=passo*15;
%separando a entrada em janelas
n_janelas=ceil(length(sinalEntrada)/tamJanela);
%zero padding
x1=[zeros(1,tamJanela/2) sinalEntrada zeros(1,((n_janelas+1)*(tamJanela))-length(sinalEntrada))];
n_passos=floor(length(sinalEntrada)/passo);
t=passo*(0:n_passos-1);
X=zeros(length(k),n_passos);
X0=zeros(length(k),n_passos);
X1=zeros(length(k),n_passos);

tic
for i=1:n_passos
    %fprintf('\r%f porcento',100*i/n_passos);
    xk=x1(((i-1)*passo+1):((i)*passo+tamJanela));
    %deixar a jenala do tamanho do sinal
    zeros2add=length(xk)-length([zeros(1,floor(length(xk)/2)-floor(tamBlackman/2)) blackman(tamBlackman)' zeros(1,floor(length(xk)/2)-floor(tamBlackman/2) )]);
    xk=[zeros(1,floor(length(xk)/2)-floor(tamBlackman/2)) blackman(tamBlackman)' zeros(1,floor(length(xk)/2)-floor(tamBlackman/2)+zeros2add )].*xk;
    for j=1:length(k)
        y=filtfilt(b(j,:),a(j,:),xk);
        X0(j,i)=sqrt(sum(y.*y));
    end
end
if aplicar_ganho
    try
    load cqt_fw_gain;
    for i=1:length(k)
        X0(i,:)=X0(i,:)*1.0/power(gain(i),1);
    end
    catch ME3
        fprintf('nao foi possivel aplicar o ganho, arquivo cqt_fw_gain.mat nao encontrado\n');
    end
end
for i=1:n_passos    
    if f0grama
        X1(:,i)=compute_f0gram(X0(:,i),fk,1);
    end
end
toc
%plotando os graficos
if f0grama~=1
    figure();
    grid on;
    subplot(1,1,1);
    imagesc(t/fs,midi,-X0);
    grid on;
    colormap('gray');
    set(gca,'YDir','normal')
    xlabel('Tempo (Segundos)');
    ylabel('Nota midi');
end
if f0grama
    figure();
    grid on;
    subplot(1,1,1);
    imagesc(t/fs,midi,-X1);
    grid on;
    colormap('gray');
    set(gca,'YDir','normal')
    xlabel('Tempo (Segundos)');
    ylabel('Nota midi');
end
fprintf('Terminou.\n');
end

