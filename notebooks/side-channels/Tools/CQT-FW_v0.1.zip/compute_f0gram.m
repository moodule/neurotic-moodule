function rho1=compute_f0gram(Xk,fk, normalizar)

% Jonathan Alis Salgado Lima
% Universidade de Brasilia
% jonathanalis@gmail.com

% computa o f0grama a partir de um espetro de frequencia
% Entradas:
% Xk eh a magnitude do espectro de frequencias.
% fk sao as frequencias de analise
% normalizar em 1 normaliza o espectro entre 0 e 1.
% Saida: rho1, o f0grama.
% esse codigo implementa a equacao 18 do artigo.

%normaliza, se for o caso
if(normalizar)
    Xk=(Xk/norm(Xk));
end

%aloca rho1.
rho1=zeros(1,length(fk));

%computa rho1.
for i=1:length(fk)
    n_subharms=floor(fk(i)/fk(1));%fk/fmin
    if n_subharms>1
        maxq=max(interp1(fk,Xk,fk(i)./(2:n_subharms), 'linear'));
        rho1(i)=Xk(i)-maxq;
    else rho1(i)=Xk(i);
    end
end
rho1=max(rho1,zeros(1,length(rho1)));
end
